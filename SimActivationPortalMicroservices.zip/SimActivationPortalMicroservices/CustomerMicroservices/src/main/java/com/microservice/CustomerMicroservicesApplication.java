package com.microservice;

import org.aspectj.lang.annotation.SuppressAjWarnings;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SuppressAjWarnings("unused")
@SpringBootApplication
@EnableFeignClients
public class CustomerMicroservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerMicroservicesApplication.class, args);
	}
	
	@Bean
	RestTemplate aNewRestTemplate()
	{
		return new RestTemplate();
	}
}
