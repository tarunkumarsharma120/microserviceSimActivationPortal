package com.microservice.DTO;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.Length;
import com.microservice.Entity.CustomerAddress;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class CustomerAddressDTO {

	private Integer addressId;
	@Length(min=0,max=25,message = "Address should be maximum of 25 characters")
	private String address;
	@Pattern(regexp = "^[ A-Za-z]+$", message = "City should not contain any special characters except space")
	private String city;
	@Length(min=6,max=6,message = "Pin should be 6 digit number")
	private String pincode;
	@Pattern(regexp = "^[ A-Za-z]+$", message = "State should not contain any special characters except space")
	private String state;
	
	public CustomerAddress convertCustomerAddressDTOtoCustomerAddressEntity()
	{
		return new CustomerAddress(this.addressId,this.address,this.city,
				this.pincode, this.state);
	}
	
	
}
