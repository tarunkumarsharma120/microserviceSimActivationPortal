package com.microservice.DTO;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import com.microservice.Entity.Customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CustomerDTO {
	@Pattern(regexp = "[0-9]{16}" , message = "Id should be 16 digit")
	private String uniqueIdNumber;
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private LocalDate dateOfBirth;
	@Email(message = "Invalid Email")
	private String emailAddress;
	@Pattern(regexp = "[a-zA-Z]+" , message = "First Name contains non alphabets")
	@Length(min = 0,max = 15)
	private String firstName;
	@Pattern(regexp = "[a-zA-Z]+" , message = "Last Name contains non alphabets")
	@Length(min = 0,max = 15)
	private String lastName;
	private String idType;
	private Integer customerAddress_addressId;
	private Integer simId;
	private String state;
	
	public CustomerDTO(@Pattern(regexp = "[0-9]{16}", message = "Id should be 16 digit") String uniqueIdNumber,
			LocalDate dateOfBirth, @Email(message = "Invalid Email") String emailAddress,
			@Pattern(regexp = "[a-zA-Z]+", message = "First Name contains non alphabets") @Length(min = 0, max = 15) String firstName,
			@Pattern(regexp = "[a-zA-Z]+", message = "Last Name contains non alphabets") @Length(min = 0, max = 15) String lastName,
			String idType, Integer customerAddress_addressId, Integer simId, String state) {
		super();
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfBirth = dateOfBirth;
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
		this.idType = idType;
		this.customerAddress_addressId = customerAddress_addressId;
		this.simId = simId;
		this.state = state;
	}

	public Customer convertCustomerDTOtoCustomerEntity()
	{
		return new Customer(this.uniqueIdNumber, this.dateOfBirth, this.emailAddress,
				this.firstName, this.lastName, this.idType, 
				this.customerAddress_addressId, this.simId, this.state);
	}
}
